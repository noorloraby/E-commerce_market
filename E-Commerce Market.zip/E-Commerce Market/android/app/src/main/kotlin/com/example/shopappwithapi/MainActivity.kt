package com.example.shopappwithapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
