import 'package:flutter/cupertino.dart';

class OnBoardingModel {
  final String image;
  final String title;
  final String body;
  OnBoardingModel({
    @required this.image,
    @required this.title,
    @required this.body,
  });
}
