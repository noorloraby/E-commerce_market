const LOGIN = 'login';
const HOME = 'home';
const GET_CATEGORIES = 'categories';
const FAVORITES = 'favorites';
const PROFILE = 'profile';
const REGISTER = 'register';
const UPDATEPROFILE = 'update-profile';
const SEARCH = 'products/search';
